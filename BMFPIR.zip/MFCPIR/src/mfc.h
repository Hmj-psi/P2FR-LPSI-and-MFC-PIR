// MFC-PIR 协议逻辑：比较码 -> 本地求 Q -> 分块填充 -> DPF 取值
#pragma once
#include <cstdint>
#include <random>
#include <string>
#include <vector>

#include "dpf.h"

namespace mfc {

using Bytes = std::vector<uint8_t>;

// ---------- 条件与比较码 ----------
enum class Rel { GT, LT, GE, LE, EQ, NONE };
struct Cond {
    std::vector<Rel> r;       // 每维的关系，NONE 表示 ∅
    std::vector<int32_t> v;   // 每维的比较值（仅 plain 模拟比较时使用）
};
Cond parse_cond(const std::string& s, size_t d);  // "0:>:30,1:==:1"

// 比较码 omega[i*d+j] ∈ {0,1,2}：0=相等，1=S 的特征>C 的值，2=S 的特征<C 的值
// 仅用于 plain 模拟；真实协议里由 SPU 的 F>、F< 得到（scripts/s3r_compare.py）
Bytes omega_plain(const std::vector<int32_t>& feat, size_t n, size_t d, const std::vector<int32_t>& v);

// 按关系把比较码变为各维的布尔结果，再按布尔表达式组合，返回满足条件的下标集合 Q
// expr 为空：对有条件的维度取合取；否则支持 c<j>、&、|、~、括号
std::vector<uint64_t> query_list(const Bytes& omega, size_t n, size_t d, const Cond& c, const std::string& expr);

// ---------- 数据库 ----------
struct Db {
    size_t n = 0, rec = 0, words = 0;  // rec：记录字节数；words：每条记录占的 uint64 数
    std::vector<uint64_t> w;           // n * words，按 8 字节对齐，便于异或
    static Db from_bytes(const uint8_t* p, size_t n, size_t rec);
};

// ---------- 分块与填充 ----------
// 选择公开上界 pad：使 Bin(qmax, 1/m) 超过 pad 的概率 < eps（假设命中均匀分布）
size_t choose_pad(size_t qmax, size_t m, double eps);

struct Plan {
    size_t n = 0, L = 0, m = 0, pad = 0, rec = 0;
    std::vector<uint64_t> slot;  // m*pad 个位置对应的全局下标，UINT64_MAX 表示填充项
};

// 客户端：生成发往 S 与 AS 的请求消息（含全部 DPF 密钥）
void client_requests(const std::vector<uint64_t>& Q, size_t n, size_t L, size_t pad, size_t rec,
                     std::mt19937_64& rng, Plan& plan, Bytes& msg_s, Bytes& msg_as);

// 服务器：解析请求，对每个密钥 FullEval 并与 DB 做 XOR 内积，返回 m*pad*rec 字节
Bytes server_answer(const Db& db, const Bytes& request, size_t threads);

// 客户端：异或两份应答，取出真实项（下标 -> 记录字节）
std::vector<std::pair<uint64_t, Bytes>> client_reconstruct(const Plan& plan, const Bytes& ra, const Bytes& rb);

}  // namespace mfc
