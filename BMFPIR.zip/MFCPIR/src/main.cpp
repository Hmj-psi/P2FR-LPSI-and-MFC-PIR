// MFC-PIR 命令行：角色 gen / all / server / aid / client / selftest
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <map>
#include <sstream>

#include "mfc.h"
#include "net.h"

using namespace mfc;
using Clock = std::chrono::steady_clock;
static double secs(Clock::time_point a, Clock::time_point b) { return std::chrono::duration<double>(b - a).count(); }

struct Args {
    std::map<std::string, std::string> kv;
    std::string str(const std::string& k, const std::string& d = "") const { auto i = kv.find(k); return i == kv.end() ? d : i->second; }
    size_t num(const std::string& k, size_t d) const { auto i = kv.find(k); return i == kv.end() ? d : std::stoull(i->second); }
    double dbl(const std::string& k, double d) const { auto i = kv.find(k); return i == kv.end() ? d : std::stod(i->second); }
    bool has(const std::string& k) const { return kv.count(k) > 0; }
};

static Bytes read_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("无法打开文件 " + path);
    return Bytes((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
}
static void write_file(const std::string& path, const Bytes& b) {
    std::ofstream f(path, std::ios::binary);
    f.write(reinterpret_cast<const char*>(b.data()), b.size());
}
// 读取比较码：.txt 为 s3r 脚本输出的 compare_result.txt（n 行，每行 d 个以空格分隔的 0/1/2）；其他为 n*d 字节的二进制
static Bytes read_omega(const std::string& path, size_t n, size_t d) {
    if (path.size() < 4 || path.compare(path.size() - 4, 4, ".txt") != 0) {
        Bytes b = read_file(path);
        if (b.size() != n * d) throw std::runtime_error("omega 二进制文件大小与 n*d 不符");
        return b;
    }
    std::ifstream f(path);
    if (!f) throw std::runtime_error("无法打开文件 " + path);
    Bytes w;
    w.reserve(n * d);
    std::string tok;
    while (f >> tok) {
        double v = std::stod(tok);  // 兼容 "1" 与 "1.0"
        int c = static_cast<int>(v + 0.5);
        if (c < 0 || c > 2) throw std::runtime_error("比较码取值必须是 0/1/2，读到 " + tok);
        w.push_back(static_cast<uint8_t>(c));
    }
    if (w.size() != n * d)
        throw std::runtime_error("compare_result.txt 共 " + std::to_string(w.size()) + " 个数，应为 n*d=" + std::to_string(n * d));
    return w;
}
static std::vector<int32_t> gen_features(size_t n, size_t d, size_t domain, uint64_t seed) {
    std::mt19937_64 g(seed);
    std::vector<int32_t> f(n * d);
    for (auto& x : f) x = static_cast<int32_t>(g() % domain);
    return f;
}
// DPF 取值的数据库：每行一个随机可打印串（rec 字节，字符集同 BKPIR），与用于比较的特征列相互独立。
// 对标 BKPIR 的 item 池（每个 item 为 -il 字节随机串）；性能实验里取回内容无关，只有长度 rec 影响开销。
static Bytes gen_payload(size_t n, size_t rec, uint64_t seed) {
    std::mt19937_64 g(seed * 1315423911ULL + 12345);
    Bytes p(n * rec);
    for (auto& x : p) x = static_cast<uint8_t>(32 + g() % 95);  // 可打印字符 ASCII 32~126，与 BKPIR 的 item 字符集一致
    return p;
}
static std::string to_hex(const uint8_t* p, size_t len) {
    static const char* h = "0123456789abcdef";
    std::string s;
    for (size_t i = 0; i < len; i++) { s += h[p[i] >> 4]; s += h[p[i] & 15]; }
    return s;
}

// s3r 比较阶段的统计（由 scripts/s3r_compare.py 写出的 compare_stats.txt）
struct S3rStats { bool ok = false; double sec = 0, mb = 0; };
static S3rStats read_s3r_stats(const std::string& path) {
    S3rStats st;
    if (path.empty()) return st;
    std::ifstream f(path);
    if (!f) throw std::runtime_error("无法打开文件 " + path);
    std::string line;
    bool a = false, b = false;
    while (std::getline(f, line)) {
        size_t p;
        if ((p = line.find("COMPARE耗时:")) != std::string::npos) { st.sec = std::stod(line.substr(p + std::strlen("COMPARE耗时:"))); a = true; }
        // 兼容两种写法：s3r_compare.py 写的"总通信:"，以及原 s3r-.py 写的"总通信量:"
        if ((p = line.find("总通信量:")) != std::string::npos) { st.mb = std::stod(line.substr(p + std::strlen("总通信量:"))); b = true; }
        else if ((p = line.find("总通信:")) != std::string::npos) { st.mb = std::stod(line.substr(p + std::strlen("总通信:"))); b = true; }
    }
    st.ok = a && b;
    if (!st.ok) throw std::runtime_error("compare_stats.txt 里没有找到 COMPARE耗时 / 总通信(量)");
    return st;
}

// 与 BKPIR 同口径的汇总：行标签与 BKPIR 的输出一致（Preparation time / Selection time / Inner product time /
// Total server time / Upload cost / Download cost），BKPIR 日志与本程序日志可用同一个脚本解析。
struct Metrics {
    size_t n = 0, d = 0, q = 0, rec = 0, threads = 1;
    double prep = 0;            // 数据库加载（离线，与查询无关）
    double locate = 0;          // client 读比较码并定位行号（本地）
    S3rStats s3r;               // s3r 比较（若提供）
    double ip = 0;              // DPF 取值：单个服务器的计算（S 与 AS 并行，取较大者）
    double up_kb = 0, down_kb = 0;
    bool ip_is_roundtrip = false;  // client 角色下只能测到“网络+服务器应答”的往返时间
};
static void print_summary(const Metrics& m, const std::string& csv) {
    double sel = m.s3r.ok ? m.s3r.sec : 0.0;  // 选择时间只算 s3r；定位行号是 client 本地计算，不计入
    double tot = sel + m.ip;
    double s3r_mb = m.s3r.ok ? m.s3r.mb : 0.0;
    double dpf_mb = (m.up_kb + m.down_kb) / 1024.0;
    std::printf("\n========== MFC-PIR 实验结果（与 BKPIR 同口径）==========\n");
    std::printf("n(行数,对应BKPIR的m)=%zu  d=%zu  |Q|=%zu  取回每行 %zu 字节  服务器线程=%zu\n", m.n, m.d, m.q, m.rec, m.threads);
    std::printf("Preparation time: %.6f seconds        (数据库加载，离线、与查询无关)\n", m.prep);
    if (m.s3r.ok) std::printf("Selection time: %.6f seconds          (s3r 比较)\n", sel);
    else std::printf("Selection time: %.6f seconds          (未提供 --s3r_stats，s3r 未计入)\n", sel);
    std::printf("  [client 本地，不计入] 定位行号: %.6f seconds\n", m.locate);
    std::printf("Inner product time: %.6f seconds      (DPF 取值%s)\n", m.ip, m.ip_is_roundtrip ? "，含网络往返" : "，单个服务器计算");
    std::printf("Total server time: %.6f seconds       (= Selection + Inner product)\n", tot);
    std::printf("Upload cost: %.2f KB                  (client -> S, AS 的 DPF 密钥)\n", m.up_kb);
    std::printf("Download cost: %.2f KB                (S, AS -> client 的应答)\n", m.down_kb);
    std::printf("Selection communication: %.2f MB      (s3r 两方比较)\n", s3r_mb);
    std::printf("Total communication: %.2f MB          (= s3r + Upload + Download)\n", s3r_mb + dpf_mb);
    if (!csv.empty()) {
        bool fresh = !std::ifstream(csv).good();
        std::ofstream f(csv, std::ios::app);
        if (fresh) f << "n,d,Q,rec_bytes,threads,prep_s,selection_s,inner_product_s,total_server_s,upload_KB,download_KB,s3r_comm_MB,total_comm_MB\n";
        f << m.n << "," << m.d << "," << m.q << "," << m.rec << "," << m.threads << "," << m.prep << "," << sel << "," << m.ip << "," << tot
          << "," << m.up_kb << "," << m.down_kb << "," << s3r_mb << "," << s3r_mb + dpf_mb << "\n";
    }
}

// 在明文特征上直接求真值（与协议路径独立），用于自检
static std::vector<uint64_t> truth_list(const std::vector<int32_t>& f, size_t n, size_t d, const Cond& c, const std::string& expr) {
    return query_list(omega_plain(f, n, d, c.v), n, d, c, expr);
}

static size_t pick_pad(const Args& a, size_t n, size_t L, size_t qcount) {
    size_t m = (n + L - 1) / L;
    if (a.has("pad")) return a.num("pad", 1);
    size_t qmax = a.num("qmax", 0);
    if (!qmax) {
        std::fprintf(stderr, "提示：未指定 --pad/--qmax，按实际 |Q| 取 qmax（会泄露 |Q|，仅用于测试）\n");
        qmax = std::max<size_t>(qcount, 1);
    }
    if (qcount > qmax) throw std::runtime_error("|Q| 超过 --qmax");
    return choose_pad(qmax, m, a.dbl("eps", 0.01));
}

static void print_records(const std::vector<std::pair<uint64_t, Bytes>>& res, const std::string& out, size_t show) {
    std::ofstream f;
    if (!out.empty()) f.open(out);
    size_t cnt = 0;
    for (auto& [idx, r] : res) {
        std::string line = std::to_string(idx) + "," + to_hex(r.data(), r.size());  // 行号,取回的随机串(十六进制)
        if (f.is_open()) f << line << "\n";
        if (cnt++ < show) std::printf("  记录 %s\n", line.c_str());
    }
}

// ---------------- all：三方在同一进程内运行（消息照常序列化，字节数是真实值） ----------------
static int role_all(const Args& a, bool verify = true) {
    size_t n = a.num("n", 4096), d = a.num("d", 3), domain = a.num("domain", 64), L = a.num("block", 65536);
    size_t rec = a.num("rec", 2), threads = a.num("threads", 1);
    std::string cond_s = a.str("cond", "0:>:30,1:==:1"), expr = a.str("expr");
    auto feat = gen_features(n, d, domain, a.num("seed", 0));
    Bytes payload = gen_payload(n, rec, a.num("seed", 0));
    Cond c = parse_cond(cond_s, d);
    Metrics M; M.n = n; M.d = d; M.rec = rec; M.threads = threads;

    auto tp0 = Clock::now();
    Db db = Db::from_bytes(payload.data(), n, rec);
    M.prep = secs(tp0, Clock::now());
    M.s3r = read_s3r_stats(a.str("s3r_stats"));

    auto t0 = Clock::now();
    Bytes omega = a.has("omega") ? read_omega(a.str("omega"), n, d) : omega_plain(feat, n, d, c.v);
    auto Q = query_list(omega, n, d, c, expr);  // 选码 + 定位行号（client 本地）
    auto t1 = Clock::now();
    M.locate = secs(t0, t1);
    M.q = Q.size();

    size_t pad = pick_pad(a, n, L, Q.size());
    std::mt19937_64 rng(a.num("seed", 0) + 7);
    Plan plan; Bytes ms, ma;
    client_requests(Q, n, L, pad, rec, rng, plan, ms, ma);
    auto t2 = Clock::now();
    Bytes rs = server_answer(db, ms, threads);
    auto t3 = Clock::now();
    Bytes ra = server_answer(db, ma, threads);
    auto t4 = Clock::now();
    auto res = client_reconstruct(plan, rs, ra);
    M.ip = std::max(secs(t2, t3), secs(t3, t4));
    M.up_kb = (ms.size() + ma.size()) / 1024.0;
    M.down_kb = (rs.size() + ra.size()) / 1024.0;

    std::printf("条件='%s' 表达式='%s'  |Q|=%zu (%.3f%%)  块长 L=%zu 块数 m=%zu pad=%zu\n", cond_s.c_str(), expr.c_str(), Q.size(), 100.0 * Q.size() / n, L, plan.m, pad);
    std::printf("客户端生成密钥: %.3fs   S 应答: %.3fs   AS 应答: %.3fs   重构: %.4fs\n", secs(t1, t2), secs(t2, t3), secs(t3, t4), secs(t4, Clock::now()));
    int rc = 0;
    if (verify) {
        auto truth = truth_list(feat, n, d, c, expr);
        bool okq = truth == Q, okr = res.size() == Q.size();
        for (auto& [idx, r] : res) okr = okr && std::memcmp(r.data(), &payload[idx * rec], rec) == 0;
        std::printf("校验：Q 与明文真值一致=%s  取回的随机串与数据库一致=%s\n", okq ? "是" : "否", okr ? "是" : "否");
        rc = (okq && okr) ? 0 : 1;
    }
    print_summary(M, a.str("stats_csv"));
    print_records(res, a.str("out"), a.num("show", 3));
    return rc;
}

// ---------------- gen：生成特征库 features.bin、比较码 omega.bin、随机串库 payload.bin ----------------
static int role_payload(const Args& a) {
    size_t n = a.num("n", 4096), rec = a.num("rec", 2);
    Bytes p = gen_payload(n, rec, a.num("seed", 0));
    write_file(a.str("payload", "payload.bin"), p);
    std::printf("已写入 %s：n=%zu 每行随机串 %zu 字节，共 %zu 字节\n", a.str("payload", "payload.bin").c_str(), n, rec, p.size());
    return 0;
}
static int role_gen(const Args& a) {
    size_t n = a.num("n", 4096), d = a.num("d", 3);
    auto f = gen_features(n, d, a.num("domain", 64), a.num("seed", 0));
    Bytes b(reinterpret_cast<uint8_t*>(f.data()), reinterpret_cast<uint8_t*>(f.data()) + f.size() * 4);
    write_file(a.str("db", "features.bin"), b);
    std::printf("已写入 %s：特征库 n=%zu d=%zu 共 %zu 字节\n", a.str("db", "features.bin").c_str(), n, d, b.size());
    // 客户端使用的比较码（s3r 的 plain 模拟输出，无安全保证；真实 s3r 用 scripts/s3r_compare.py）
    Cond c = parse_cond(a.str("cond", "0:>:30,1:==:1"), d);
    Bytes omega = omega_plain(f, n, d, c.v);
    write_file(a.str("omega", "omega.bin"), omega);
    std::printf("已写入 %s：比较码 %zu 字节（条件 %s）\n", a.str("omega", "omega.bin").c_str(), omega.size(), a.str("cond", "0:>:30,1:==:1").c_str());
    return role_payload(a);
}

// ---------------- server / aid：加载同一份数据库，监听并应答 ----------------
static int role_server(const Args& a, const char* name) {
    size_t n = a.num("n", 4096), rec = a.num("rec", 2);
    auto tp0 = Clock::now();
    Bytes raw = read_file(a.str("payload", "payload.bin"));
    if (raw.size() != n * rec) throw std::runtime_error("payload 文件大小与 n*rec 不符");
    Db db = Db::from_bytes(raw.data(), n, rec);
    double prep = secs(tp0, Clock::now());
    int ls = net::listen_on(static_cast<int>(a.num("port", 9001)));
    size_t rounds = a.num("rounds", 1);
    std::printf("[%s] 监听 %zu，随机串库 n=%zu 每行 %zu 字节，加载 %.3fs\n", name, a.num("port", 9001), n, rec, prep);
    std::fflush(stdout);
    for (size_t r = 0; r < rounds; r++) {
        int fd = ::accept(ls, nullptr, nullptr);
        Bytes req = net::recv_msg(fd);
        auto t0 = Clock::now();
        Bytes resp = server_answer(db, req, a.num("threads", 1));
        auto t1 = Clock::now();
        net::send_msg(fd, resp);
        std::printf("[%s] 收到 %.1f KB，应答 %.1f KB，计算 %.6fs\n", name, req.size() / 1024.0, resp.size() / 1024.0, secs(t0, t1));
        std::fflush(stdout);
        ::close(fd);
    }
    return 0;
}

// ---------------- client：读比较码，求 Q，经 TCP 向 S 与 AS 取值 ----------------
static int role_client(const Args& a) {
    size_t n = a.num("n", 4096), d = a.num("d", 3), L = a.num("block", 65536), rec = a.num("rec", 2);
    std::string cond_s = a.str("cond", "0:>:30,1:==:1"), expr = a.str("expr");
    Cond c = parse_cond(cond_s, d);
    Metrics M; M.n = n; M.d = d; M.rec = rec; M.threads = a.num("threads", 1); M.ip_is_roundtrip = true;
    M.s3r = read_s3r_stats(a.str("s3r_stats"));
    auto t0 = Clock::now();
    Bytes omega = read_omega(a.str("omega", "omega.bin"), n, d);
    auto Q = query_list(omega, n, d, c, expr);  // 选码 + 定位行号
    auto t1 = Clock::now();
    M.locate = secs(t0, t1);
    M.q = Q.size();
    size_t pad = pick_pad(a, n, L, Q.size());
    std::mt19937_64 rng(std::random_device{}());
    Plan plan; Bytes ms, ma;
    client_requests(Q, n, L, pad, rec, rng, plan, ms, ma);
    auto t2 = Clock::now();
    int fs = net::connect_to(a.str("server", "127.0.0.1:9001"));
    int fa = net::connect_to(a.str("aid", "127.0.0.1:9002"));
    auto t3 = Clock::now();
    net::send_msg(fs, ms);
    net::send_msg(fa, ma);
    Bytes rs = net::recv_msg(fs), ra = net::recv_msg(fa);
    auto t4 = Clock::now();
    auto res = client_reconstruct(plan, rs, ra);
    M.ip = secs(t3, t4);
    M.up_kb = (ms.size() + ma.size()) / 1024.0;
    M.down_kb = (rs.size() + ra.size()) / 1024.0;
    std::printf("|Q|=%zu 块数 m=%zu pad=%zu  客户端生成密钥 %.3fs\n", Q.size(), plan.m, pad, secs(t1, t2));
    print_summary(M, a.str("stats_csv"));
    print_records(res, a.str("out"), a.num("show", 3));
    return 0;
}

// ---------------- selftest ----------------
static int role_selftest() {
    int bad = 0;
    struct Case { size_t n, d, domain, L; const char* cond; const char* expr; size_t qmax; size_t rec; };
    const Case cases[] = {
        {3000, 3, 64, 65536, "0:>:30,1:==:1", "", 200, 2},
        {5000, 3, 8, 1024, "0:>=:5,1:<:3,2:==:4", "(c0 & c1) | (c2 & ~c0)", 1800, 5},  // 多块 + 布尔表达式
        {4097, 2, 100, 64, "0:<=:3,1:>:95", "", 100, 14},                              // 块长很小：块数多，末块不满
        {1000, 1, 10, 256, "0:==:7", "", 300, 32},
    };
    int idx = 0;
    for (const auto& cs : cases) {
        Args a;
        a.kv = {{"n", std::to_string(cs.n)}, {"d", std::to_string(cs.d)}, {"domain", std::to_string(cs.domain)},
                {"block", std::to_string(cs.L)}, {"rec", std::to_string(cs.rec)}, {"cond", cs.cond}, {"expr", cs.expr}, {"qmax", std::to_string(cs.qmax)},
                {"seed", std::to_string(idx + 1)}, {"threads", "2"}, {"show", "0"}, {"eps", "0.0001"}};
        std::printf("---- 用例 %d ----\n", ++idx);
        int rc = 0;
        try { rc = role_all(a); } catch (const std::exception& e) { std::printf("异常: %s\n", e.what()); rc = 1; }
        bad += rc;
    }
    // 超过公开上界必须拒绝
    try {
        std::vector<uint64_t> Q = {0, 1, 2, 3, 4};
        std::mt19937_64 rng(1);
        Plan p; Bytes a, b;
        client_requests(Q, 100, 100, 2, 4, rng, p, a, b);
        std::printf("上界检查：应当拒绝却通过了\n"); bad++;
    } catch (const std::exception&) { std::printf("上界检查：正确拒绝了 |Q|>pad\n"); }
    std::printf("selftest %s\n", bad ? "失败" : "全部通过");
    return bad ? 1 : 0;
}

int main(int argc, char** argv) {
    Args a;
    for (int i = 1; i + 1 < argc; i += 2) {
        std::string k = argv[i];
        if (k.rfind("--", 0) != 0) { std::fprintf(stderr, "参数应为 --key value：%s\n", argv[i]); return 2; }
        a.kv[k.substr(2)] = argv[i + 1];
    }
    try {
        std::string role = a.str("role", "all");
        if (role == "all") return role_all(a);
        if (role == "gen") return role_gen(a);
        if (role == "payload") return role_payload(a);
        if (role == "server") return role_server(a, "S");
        if (role == "aid") return role_server(a, "AS");
        if (role == "client") return role_client(a);
        if (role == "selftest") return role_selftest();
        std::fprintf(stderr, "未知角色 %s\n", role.c_str());
        return 2;
    } catch (const std::exception& e) {
        std::fprintf(stderr, "错误: %s\n", e.what());
        return 1;
    }
}
