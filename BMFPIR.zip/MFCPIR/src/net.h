// 极简 TCP（阻塞）：长度前缀消息
#pragma once
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

namespace mfc {
namespace net {

inline void send_all(int fd, const void* p, size_t n) {
    const char* c = static_cast<const char*>(p);
    while (n) {
        ssize_t k = ::send(fd, c, n, MSG_NOSIGNAL);
        if (k <= 0) throw std::runtime_error("send 失败");
        c += k; n -= k;
    }
}
inline void recv_all(int fd, void* p, size_t n) {
    char* c = static_cast<char*>(p);
    while (n) {
        ssize_t k = ::recv(fd, c, n, 0);
        if (k <= 0) throw std::runtime_error("recv 失败或对端关闭");
        c += k; n -= k;
    }
}
inline void send_msg(int fd, const std::vector<uint8_t>& b) {
    uint64_t len = b.size();
    send_all(fd, &len, 8);
    send_all(fd, b.data(), b.size());
}
inline std::vector<uint8_t> recv_msg(int fd) {
    uint64_t len;
    recv_all(fd, &len, 8);
    if (len > (uint64_t(1) << 36)) throw std::runtime_error("消息过大");
    std::vector<uint8_t> b(len);
    recv_all(fd, b.data(), len);
    return b;
}
inline int listen_on(int port) {
    int s = ::socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = INADDR_ANY;
    a.sin_port = htons(port);
    if (::bind(s, reinterpret_cast<sockaddr*>(&a), sizeof(a)) || ::listen(s, 4)) throw std::runtime_error("监听端口失败");
    return s;
}
inline int connect_to(const std::string& hostport) {
    size_t c = hostport.rfind(':');
    if (c == std::string::npos) throw std::invalid_argument("地址应为 host:port");
    addrinfo hints{}, *res;
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(hostport.substr(0, c).c_str(), hostport.substr(c + 1).c_str(), &hints, &res)) throw std::runtime_error("解析地址失败");
    int s = -1;
    for (int tries = 0; tries < 100; tries++) {  // 服务器可能稍晚启动，重试约 10 秒
        s = ::socket(AF_INET, SOCK_STREAM, 0);
        if (::connect(s, res->ai_addr, res->ai_addrlen) == 0) break;
        ::close(s); s = -1;
        usleep(100000);
    }
    freeaddrinfo(res);
    if (s < 0) throw std::runtime_error("连接 " + hostport + " 失败");
    int one = 1;
    setsockopt(s, IPPROTO_TCP, 1 /*TCP_NODELAY*/, &one, sizeof(one));
    return s;
}

}  // namespace net
}  // namespace mfc
