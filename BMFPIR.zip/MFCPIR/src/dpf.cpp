#include "dpf.h"

#include <emmintrin.h>
#include <wmmintrin.h>

#include <cstdio>
#include <cstring>
#include <stdexcept>

namespace mfc {
namespace dpf {
namespace {

// 与 DPFPSI 的 AESKEY 相同
const uint8_t kAesKey[16] = {0xeb, 0x28, 0xcc, 0xa6, 0x5c, 0x64, 0x48, 0xa1,
                             0xf9, 0x98, 0x02, 0xe8, 0x68, 0x0c, 0x70, 0xfd};

struct Aes {  // 来自 dpf/AES.h 的 mAES（AES-NI 固定密钥）
    __m128i rk[11];
    static __m128i helper(__m128i key, __m128i rcon) {
        rcon = _mm_shuffle_epi32(rcon, _MM_SHUFFLE(3, 3, 3, 3));
        key = _mm_xor_si128(key, _mm_slli_si128(key, 4));
        key = _mm_xor_si128(key, _mm_slli_si128(key, 4));
        key = _mm_xor_si128(key, _mm_slli_si128(key, 4));
        return _mm_xor_si128(key, rcon);
    }
    Aes() {
        rk[0] = _mm_loadu_si128(reinterpret_cast<const __m128i*>(kAesKey));
        rk[1] = helper(rk[0], _mm_aeskeygenassist_si128(rk[0], 0x01));
        rk[2] = helper(rk[1], _mm_aeskeygenassist_si128(rk[1], 0x02));
        rk[3] = helper(rk[2], _mm_aeskeygenassist_si128(rk[2], 0x04));
        rk[4] = helper(rk[3], _mm_aeskeygenassist_si128(rk[3], 0x08));
        rk[5] = helper(rk[4], _mm_aeskeygenassist_si128(rk[4], 0x10));
        rk[6] = helper(rk[5], _mm_aeskeygenassist_si128(rk[5], 0x20));
        rk[7] = helper(rk[6], _mm_aeskeygenassist_si128(rk[6], 0x40));
        rk[8] = helper(rk[7], _mm_aeskeygenassist_si128(rk[7], 0x80));
        rk[9] = helper(rk[8], _mm_aeskeygenassist_si128(rk[8], 0x1B));
        rk[10] = helper(rk[9], _mm_aeskeygenassist_si128(rk[9], 0x36));
    }
    __m128i enc(__m128i x) const {
        x = _mm_xor_si128(x, rk[0]);
        for (int i = 1; i < 10; i++) x = _mm_aesenc_si128(x, rk[i]);
        return _mm_aesenclast_si128(x, rk[10]);
    }
};
const Aes& aes() {
    static const Aes a;
    return a;
}

inline uint64_t lo64(__m128i x) { return static_cast<uint64_t>(_mm_cvtsi128_si64(x)); }
inline uint64_t hi64(__m128i x) { return static_cast<uint64_t>(_mm_cvtsi128_si64(_mm_unpackhi_epi64(x, x))); }
inline __m128i make(uint64_t hi, uint64_t lo) { return _mm_set_epi64x(static_cast<long long>(hi), static_cast<long long>(lo)); }

// Keyed_hash_func: H(x) = AES_k(x) ^ sigma(x)，sigma(lo,hi) = (lo^hi, lo)
inline __m128i H(__m128i x) {
    uint64_t lo = lo64(x), hi = hi64(x);
    return _mm_xor_si128(aes().enc(x), make(lo, lo ^ hi));
}

inline bool lsb(__m128i x) { return (lo64(x) & 1) != 0; }
inline __m128i flip0(__m128i x) { return _mm_xor_si128(x, make(0, 1)); }
inline __m128i set_lsb(__m128i x, bool b) {
    x = _mm_andnot_si128(make(0, 1), x);
    return b ? _mm_or_si128(x, make(0, 1)) : x;
}
inline uint8_t byte0(__m128i x) { return static_cast<uint8_t>(lo64(x) & 0xFF); }
inline __m128i with_byte0(__m128i x, uint8_t b) {
    x = _mm_andnot_si128(make(0, 0xFF), x);
    return _mm_or_si128(x, make(0, b));
}
// Convert_to_G：取 16 字节中的第 1..8 字节
inline uint64_t G(__m128i x) { return (lo64(x) >> 8) | ((hi64(x) & 0xFF) << 56); }

inline __m128i load(const Seed& s) { return _mm_loadu_si128(reinterpret_cast<const __m128i*>(s.data())); }
inline Seed store(__m128i x) {
    Seed s;
    _mm_storeu_si128(reinterpret_cast<__m128i*>(s.data()), x);
    return s;
}
inline __m128i rand_block() {
    Seed s;
    rand_bytes(s.data(), s.size());
    return load(s);
}
inline bool bit(size_t v, size_t i) { return (v >> i) & 1; }

struct EvalCtx {
    __m128i cw[kHigh - 1];
    __m128i mid0, mid1;
    uint64_t cw_n1;
    size_t L;
    uint64_t* out;
};

void eval_node(const EvalCtx& c, __m128i s, size_t depth, size_t pos) {
    // 该子树覆盖的第一个叶子位置；整棵子树都在 L 之外则剪枝
    size_t start = (pos << (kHigh - 1 - depth)) * 128;
    if (start >= c.L) return;
    if (depth == kHigh - 1) {
        __m128i n0 = H(s);
        __m128i n1 = H(flip0(s));
        if (lsb(s)) {
            n0 = _mm_xor_si128(n0, c.mid0);
            n1 = _mm_xor_si128(n1, c.mid1);
        }
        uint64_t f0 = lsb(n0) ? ~uint64_t(0) : 0;
        uint64_t f1 = lsb(n1) ? ~uint64_t(0) : 0;
        c.out[2 * pos] = G(n0) ^ (c.cw_n1 & f0);
        c.out[2 * pos + 1] = G(n1) ^ (c.cw_n1 & f1);
        return;
    }
    __m128i h = H(s);
    if (lsb(s)) h = _mm_xor_si128(h, c.cw[kHigh - 2 - depth]);
    __m128i x = _mm_xor_si128(h, s);
    eval_node(c, h, depth + 1, 2 * pos);
    eval_node(c, x, depth + 1, 2 * pos + 1);
}

}  // namespace

void rand_bytes(uint8_t* buf, size_t len) {
    static FILE* f = std::fopen("/dev/urandom", "rb");
    if (!f || std::fread(buf, 1, len, f) != len) throw std::runtime_error("读取 /dev/urandom 失败");
}

void gen(size_t alpha, Key& k0, Key& k1) {
    if (alpha >= kDomain) throw std::out_of_range("alpha 超出 DPF 域");
    __m128i delta = set_lsb(rand_block(), true);
    __m128i s0 = rand_block();
    __m128i s1 = _mm_xor_si128(s0, delta);
    k0.share = store(s0);
    k1.share = store(s1);

    for (size_t i = kInputBits - 1; i > kEarlyBits; i--) {
        __m128i h0 = H(s0), h1 = H(s1);
        __m128i cw = _mm_xor_si128(h0, h1), n0, n1;
        if (bit(alpha, i)) {
            n0 = _mm_xor_si128(s0, h0);
            n1 = _mm_xor_si128(s1, h1);
        } else {
            cw = _mm_xor_si128(cw, delta);
            n0 = h0;
            n1 = h1;
        }
        if (lsb(s0)) n0 = _mm_xor_si128(n0, cw);
        if (lsb(s1)) n1 = _mm_xor_si128(n1, cw);
        k0.cw[i - 1 - kEarlyBits] = k1.cw[i - 1 - kEarlyBits] = store(cw);
        s0 = n0;
        s1 = n1;
    }

    // 早停层：High_Low_super{0,1}_sub{0,1}
    __m128i s0x = flip0(s0), s1x = flip0(s1);
    __m128i h00 = H(s0), h10 = H(s0x), h01 = H(s1), h11 = H(s1x);
    bool a6 = bit(alpha, kEarlyBits);
    __m128i hcw = a6 ? _mm_xor_si128(h00, h01) : _mm_xor_si128(h10, h11);
    hcw = set_lsb(hcw, lsb(h00) ^ lsb(h01) ^ !a6);
    uint8_t last = byte0(hcw);
    bool lb = lsb(h10) ^ lsb(h11) ^ a6;
    last = lb ? (last | 1) : (last & 0xFE);
    k0.hcw = k1.hcw = store(hcw);
    k0.last = k1.last = last;

    __m128i hcw_lcw = a6 ? with_byte0(hcw, last) : hcw;
    __m128i n0 = a6 ? h10 : h00;
    __m128i n1 = a6 ? h11 : h01;
    if (lsb(s0)) n0 = _mm_xor_si128(n0, hcw_lcw);
    if (lsb(s1)) n1 = _mm_xor_si128(n1, hcw_lcw);

    uint64_t beta = uint64_t(1) << (alpha & ((1u << kEarlyBits) - 1));
    uint64_t cw_n1 = G(n0) ^ G(n1) ^ beta;
    std::memcpy(k0.cw_n1.data(), &cw_n1, 8);
    k1.cw_n1 = k0.cw_n1;
}

void full_eval(const Key& k, size_t L, uint64_t* out) {
    if (L == 0 || L > kDomain) throw std::out_of_range("块长 L 必须在 (0, 2^16]");
    std::memset(out, 0, kWords * sizeof(uint64_t));
    EvalCtx c;
    for (size_t i = 0; i < kHigh - 1; i++) c.cw[i] = load(k.cw[i]);
    c.mid0 = load(k.hcw);
    c.mid1 = with_byte0(c.mid0, k.last);
    std::memcpy(&c.cw_n1, k.cw_n1.data(), 8);
    c.L = L;
    c.out = out;
    eval_node(c, load(k.share), 0, 0);
}

void serialize(const Key& k, uint8_t* out) {
    size_t o = 0;
    std::memcpy(out + o, k.share.data(), 16); o += 16;
    for (const auto& c : k.cw) { std::memcpy(out + o, c.data(), 16); o += 16; }
    std::memcpy(out + o, k.hcw.data(), 16); o += 16;
    out[o++] = k.last;
    std::memcpy(out + o, k.cw_n1.data(), 8);
}

Key deserialize(const uint8_t* in) {
    Key k;
    size_t o = 0;
    std::memcpy(k.share.data(), in + o, 16); o += 16;
    for (auto& c : k.cw) { std::memcpy(c.data(), in + o, 16); o += 16; }
    std::memcpy(k.hcw.data(), in + o, 16); o += 16;
    k.last = in[o++];
    std::memcpy(k.cw_n1.data(), in + o, 8);
    return k;
}

}  // namespace dpf
}  // namespace mfc
