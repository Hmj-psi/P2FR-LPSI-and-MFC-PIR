// 自 DPFPSI 的 src/psi/dpf（pcGGM，早停 GGM 树 DPF）改写而来：
//  - 去掉对 Cuckoo 参数(cuckoo::block_size/max_set_size)、droidCrypto、OpenSSL 的依赖
//  - 块长 L 作为运行时参数（L <= 2^16），不再是编译期常量
//  - 算法本身（Gen 的校正字构造、早停叶子压缩、AES 固定密钥哈希 H(x)=AES(x)^sigma(x)）保持不变
#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace mfc {
namespace dpf {

constexpr size_t kInputBits = 16;                  // DPF_INPUT_BIT_SIZE
constexpr size_t kDomain = size_t(1) << kInputBits;  // 单个块最多 65536 个叶子
constexpr size_t kEarlyBits = 6;                   // DPF_EARLY_BIT_SIZE
constexpr size_t kHigh = kInputBits - kEarlyBits;  // DPF_EAYLY_HIGH = 10
constexpr size_t kWords = kDomain / 64;            // 叶子位图的 uint64 个数

using Seed = std::array<uint8_t, 16>;

struct Key {
    Seed share;
    std::array<Seed, kHigh - 1> cw;
    Seed hcw;
    uint8_t last;
    std::array<uint8_t, 8> cw_n1;
};

constexpr size_t kKeyBytes = 16 + 16 * (kHigh - 1) + 16 + 1 + 8;  // 185

void rand_bytes(uint8_t* buf, size_t len);                  // /dev/urandom
void gen(size_t alpha, Key& k0, Key& k1);                   // alpha < 2^16
// 展开前 L 个叶子，out 长度为 kWords；两方输出异或后仅 alpha 位为 1
void full_eval(const Key& k, size_t L, uint64_t* out);
void serialize(const Key& k, uint8_t* out);                 // 写 kKeyBytes 字节
Key deserialize(const uint8_t* in);

}  // namespace dpf
}  // namespace mfc
