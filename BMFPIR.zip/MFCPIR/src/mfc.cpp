#include "mfc.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <thread>

namespace mfc {
namespace {

constexpr uint32_t kMagic = 0x4D464331;  // "MFC1"
constexpr size_t kHdr = 32;

void put32(Bytes& b, size_t off, uint32_t v) { std::memcpy(&b[off], &v, 4); }
void put64(Bytes& b, size_t off, uint64_t v) { std::memcpy(&b[off], &v, 8); }
uint32_t get32(const Bytes& b, size_t off) { uint32_t v; std::memcpy(&v, &b[off], 4); return v; }
uint64_t get64(const Bytes& b, size_t off) { uint64_t v; std::memcpy(&v, &b[off], 8); return v; }

Rel parse_rel(const std::string& s) {
    if (s == ">") return Rel::GT;
    if (s == "<") return Rel::LT;
    if (s == ">=") return Rel::GE;
    if (s == "<=") return Rel::LE;
    if (s == "==" || s == "=") return Rel::EQ;
    throw std::invalid_argument("未知关系: " + s);
}

// 各关系在 omega = 0/1/2（等于/大于/小于）下是否成立，与论文 Table II 的真值表一致
bool rel_ok(Rel r, uint8_t w) {
    switch (r) {
        case Rel::GT: return w == 1;
        case Rel::LT: return w == 2;
        case Rel::GE: return w == 0 || w == 1;
        case Rel::LE: return w == 0 || w == 2;
        case Rel::EQ: return w == 0;
        default: return true;
    }
}

// ---------- 布尔表达式：expr := term ('|' term)*; term := fac ('&' fac)*; fac := '~'fac | '('expr')' | 'c'数字
struct Parser {
    const std::string& s;
    size_t p = 0;
    const std::vector<Bytes>& sat;
    size_t n;
    Parser(const std::string& s_, const std::vector<Bytes>& sat_, size_t n_) : s(s_), sat(sat_), n(n_) {}
    void ws() { while (p < s.size() && s[p] == ' ') p++; }
    Bytes expr() {
        Bytes a = term();
        ws();
        while (p < s.size() && s[p] == '|') {
            p++;
            Bytes b = term();
            for (size_t i = 0; i < n; i++) a[i] |= b[i];
            ws();
        }
        return a;
    }
    Bytes term() {
        Bytes a = fac();
        ws();
        while (p < s.size() && s[p] == '&') {
            p++;
            Bytes b = fac();
            for (size_t i = 0; i < n; i++) a[i] &= b[i];
            ws();
        }
        return a;
    }
    Bytes fac() {
        ws();
        if (p >= s.size()) throw std::invalid_argument("表达式不完整");
        if (s[p] == '~') {
            p++;
            Bytes a = fac();
            for (auto& x : a) x = !x;
            return a;
        }
        if (s[p] == '(') {
            p++;
            Bytes a = expr();
            ws();
            if (p >= s.size() || s[p] != ')') throw std::invalid_argument("缺少 )");
            p++;
            return a;
        }
        if (s[p] == 'c') {
            p++;
            size_t j = 0, k = 0;
            while (p < s.size() && isdigit(static_cast<unsigned char>(s[p]))) { j = j * 10 + (s[p] - '0'); p++; k++; }
            if (!k || j >= sat.size()) throw std::invalid_argument("表达式里的维度编号越界");
            return sat[j];
        }
        throw std::invalid_argument(std::string("表达式里有非法字符: ") + s[p]);
    }
};

}  // namespace

Cond parse_cond(const std::string& s, size_t d) {
    Cond c;
    c.r.assign(d, Rel::NONE);
    c.v.assign(d, 0);
    size_t pos = 0;
    while (pos < s.size()) {
        size_t e = s.find(',', pos);
        std::string item = s.substr(pos, e == std::string::npos ? std::string::npos : e - pos);
        pos = (e == std::string::npos) ? s.size() : e + 1;
        if (item.empty()) continue;
        size_t a = item.find(':'), b = item.find(':', a + 1);
        if (a == std::string::npos || b == std::string::npos) throw std::invalid_argument("条件格式应为 j:关系:值");
        size_t j = std::stoul(item.substr(0, a));
        if (j >= d) throw std::invalid_argument("条件维度越界");
        c.r[j] = parse_rel(item.substr(a + 1, b - a - 1));
        c.v[j] = std::stoi(item.substr(b + 1));
    }
    return c;
}

Bytes omega_plain(const std::vector<int32_t>& feat, size_t n, size_t d, const std::vector<int32_t>& v) {
    Bytes w(n * d);
    for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < d; j++) {
            int32_t x = feat[i * d + j];
            w[i * d + j] = (x > v[j] ? 1 : 0) + (x < v[j] ? 2 : 0);
        }
    return w;
}

std::vector<uint64_t> query_list(const Bytes& omega, size_t n, size_t d, const Cond& c, const std::string& expr) {
    if (omega.size() != n * d) throw std::invalid_argument("比较码大小与 n*d 不符");
    std::vector<Bytes> sat(d, Bytes(n, 1));
    for (size_t j = 0; j < d; j++)
        for (size_t i = 0; i < n; i++) sat[j][i] = rel_ok(c.r[j], omega[i * d + j]);
    Bytes keep(n, 1);
    if (expr.empty()) {
        for (size_t j = 0; j < d; j++)
            if (c.r[j] != Rel::NONE)
                for (size_t i = 0; i < n; i++) keep[i] &= sat[j][i];
    } else {
        Parser ps(expr, sat, n);
        keep = ps.expr();
        ps.ws();
        if (ps.p != expr.size()) throw std::invalid_argument("表达式尾部有多余内容");
    }
    std::vector<uint64_t> Q;
    for (size_t i = 0; i < n; i++)
        if (keep[i]) Q.push_back(i);
    return Q;
}

Db Db::from_bytes(const uint8_t* p, size_t n_, size_t rec_) {
    Db db;
    db.n = n_;
    db.rec = rec_;
    db.words = (rec_ + 7) / 8;
    db.w.assign(n_ * db.words, 0);
    for (size_t i = 0; i < n_; i++) std::memcpy(&db.w[i * db.words], p + i * rec_, rec_);
    return db;
}

size_t choose_pad(size_t qmax, size_t m, double eps) {
    if (m <= 1 || qmax == 0) return std::max<size_t>(qmax, 1);
    double p = 1.0 / m, lp = std::log(p), lq = std::log1p(-p), cdf = 0;
    for (size_t t = 0; t <= qmax; t++) {
        double lg = std::lgamma(qmax + 1.0) - std::lgamma(t + 1.0) - std::lgamma(qmax - t + 1.0);
        cdf += std::exp(lg + t * lp + (qmax - t) * lq);
        if (1.0 - cdf < eps) return std::max<size_t>(t, 1);
    }
    return qmax;
}

void client_requests(const std::vector<uint64_t>& Q, size_t n, size_t L, size_t pad, size_t rec,
                     std::mt19937_64& rng, Plan& plan, Bytes& msg_s, Bytes& msg_as) {
    if (L == 0 || L > dpf::kDomain) throw std::invalid_argument("块长 L 必须在 (0, 65536]");
    size_t m = (n + L - 1) / L;
    std::vector<std::vector<size_t>> per(m);
    for (uint64_t q : Q) per[q / L].push_back(q % L);
    for (size_t p = 0; p < m; p++)
        if (per[p].size() > pad)
            throw std::runtime_error("块 " + std::to_string(p) + " 命中 " + std::to_string(per[p].size()) +
                                     " 条，超过公开上界 pad=" + std::to_string(pad) + "；请增大 --pad 或 --qmax");
    plan = Plan{n, L, m, pad, rec, std::vector<uint64_t>(m * pad, UINT64_MAX)};
    msg_s.assign(kHdr + m * pad * dpf::kKeyBytes, 0);
    msg_as.assign(kHdr + m * pad * dpf::kKeyBytes, 0);
    for (Bytes* b : {&msg_s, &msg_as}) {
        put32(*b, 0, kMagic);
        put32(*b, 4, static_cast<uint32_t>(m));
        put32(*b, 8, static_cast<uint32_t>(pad));
        put32(*b, 12, static_cast<uint32_t>(L));
        put32(*b, 16, static_cast<uint32_t>(rec));
        put64(*b, 24, n);
    }
    for (size_t p = 0; p < m; p++) {
        size_t Lp = std::min(L, n - p * L);
        std::vector<std::pair<size_t, bool>> items;  // (块内偏移, 是否真实)
        for (size_t o : per[p]) items.push_back({o, true});
        while (items.size() < pad) items.push_back({rng() % Lp, false});
        std::shuffle(items.begin(), items.end(), rng);  // 打乱真实项与填充项的位置
        for (size_t j = 0; j < pad; j++) {
            dpf::Key k0, k1;
            dpf::gen(items[j].first, k0, k1);
            size_t idx = p * pad + j;
            dpf::serialize(k0, &msg_s[kHdr + idx * dpf::kKeyBytes]);
            dpf::serialize(k1, &msg_as[kHdr + idx * dpf::kKeyBytes]);
            if (items[j].second) plan.slot[idx] = p * L + items[j].first;
        }
    }
}

Bytes server_answer(const Db& db, const Bytes& req, size_t threads) {
    if (req.size() < kHdr || get32(req, 0) != kMagic) throw std::runtime_error("请求格式错误");
    size_t m = get32(req, 4), pad = get32(req, 8), L = get32(req, 12), rec = get32(req, 16);
    uint64_t n = get64(req, 24);
    if (n != db.n || rec != db.rec) throw std::runtime_error("请求中的 n 或记录长度与服务器数据库不一致");
    if (req.size() != kHdr + m * pad * dpf::kKeyBytes) throw std::runtime_error("请求长度与头部不符");
    size_t total = m * pad;
    Bytes out(total * rec, 0);
    std::atomic<size_t> next{0};
    auto worker = [&]() {
        std::vector<uint64_t> leaf(dpf::kWords), acc(db.words);
        for (;;) {
            size_t t = next.fetch_add(1);
            if (t >= total) break;
            size_t p = t / pad, Lp = std::min<size_t>(L, db.n - p * L);
            dpf::Key k = dpf::deserialize(&req[kHdr + t * dpf::kKeyBytes]);
            dpf::full_eval(k, Lp, leaf.data());
            std::fill(acc.begin(), acc.end(), 0);
            size_t nw = (Lp + 63) / 64;
            for (size_t i = 0; i < nw; i++) {
                uint64_t x = leaf[i];
                while (x) {
                    size_t o = i * 64 + __builtin_ctzll(x);
                    x &= x - 1;
                    if (o >= Lp) break;
                    const uint64_t* r = &db.w[(p * L + o) * db.words];
                    for (size_t q = 0; q < db.words; q++) acc[q] ^= r[q];
                }
            }
            std::memcpy(&out[t * rec], acc.data(), rec);
        }
    };
    threads = std::max<size_t>(1, threads);
    std::vector<std::thread> th;
    for (size_t i = 1; i < threads; i++) th.emplace_back(worker);
    worker();
    for (auto& t : th) t.join();
    return out;
}

std::vector<std::pair<uint64_t, Bytes>> client_reconstruct(const Plan& plan, const Bytes& ra, const Bytes& rb) {
    size_t total = plan.m * plan.pad;
    if (ra.size() != total * plan.rec || rb.size() != ra.size()) throw std::runtime_error("应答长度不符");
    std::vector<std::pair<uint64_t, Bytes>> res;
    for (size_t t = 0; t < total; t++) {
        if (plan.slot[t] == UINT64_MAX) continue;
        Bytes r(plan.rec);
        for (size_t i = 0; i < plan.rec; i++) r[i] = ra[t * plan.rec + i] ^ rb[t * plan.rec + i];
        res.push_back({plan.slot[t], std::move(r)});
    }
    std::sort(res.begin(), res.end(), [](auto& a, auto& b) { return a.first < b.first; });
    return res;
}

}  // namespace mfc
