# MFC-PIR（基于 DPFPSI 的 pcGGM DPF 改写）

## 编译
    make            # 需要 g++ (C++17)、支持 AES-NI 的 x86 CPU

## 流程（与 BKPIR 同口径）
| 阶段 | 做什么 | 对标 BKPIR |
|---|---|---|
| 离线 | S、AS 加载同一份随机串库 payload.bin（每行 `--rec` 字节） | Preparation time |
| 选择 | s3r 比较得到比较码 ω；client 对每维选码（0/1/2）并定位满足所有维度的行号集合 Q | Selection time |
| 取值 | client 对 Q 分块填充，生成 DPF 密钥发给 S、AS；两方对同一份 payload 求值，client 异或得到各行的随机串 | Inner product time |

输出标签与 BKPIR 一致：`Preparation time / Selection time / Inner product time / Total server time / Upload cost / Download cost`，
另有 `Selection communication`（s3r 通信）和 `Total communication`。完整的口径、对齐规则、参数表和运行指令见 `COMPARE.md`。

## 运行
    ./mfcpir --role all --n 8192 --d 20 --rec 2 --cond "0:>=:0" --qmax 8192 --block 4096 --threads 1   # 三方同进程，通信字节为真实值
    bash scripts/run_pipeline.sh                      # 三进程；USE_S3R=1 接入真实 s3r
    bash scripts/bench_align.sh                       # 与 BKPIR 对齐的参数扫描，输出 mfc_align.csv

三进程分步：`--role gen`（特征库、比较码、随机串库）或 `--role payload`（只生成随机串库）→ `--role server` / `--role aid`（`--payload`）→ `--role client`（`--omega`、`--s3r_stats`、`--stats_csv`）。
取回结果写入 `--out`，每行 `行号,随机串(十六进制)`。`--role client` 下 `Inner product time` 含网络往返，`Preparation time` 在 server/aid 日志里。

## 条件语法
`--cond "列:关系:阈值,..."`，关系 ∈ `> < >= <= ==`；`--expr` 可写布尔表达式，如 `"(c0 & c1) | (c2 & ~c0)"`（ci 为第 i 个条件）。

## 自测
    ./mfcpir --role selftest


## 完整流程（接入真实 s3r 比较）
1. **s3r 比较**：`python scripts/s3r_compare.py --n 1331000 --d 20 --thr "30,1,..." --out data/`
   输出 `features.bin`（数据库）、`omega.bin` 与 `compare_result.txt`（比较码 ω，0=相等 1=大于 2=小于）、`compare_stats.txt`（耗时/通信）。
2. **选码求 Q**：client 对每一维选定关系（`>`→码1，`<`→码2，`==`→码0，`>=`→码{0,1}，`<=`→码{0,2}，不写则不约束），
   在 ω 中找出所有维度都满足的行号集合 Q（`--omega data/omega.bin` 或 `data/compare_result.txt`）。
3. **DPF 取值**：取的是与特征列无关的随机串库 `payload.bin`（`--role payload` 生成）。
    ./mfcpir --role payload --n 1331000 --rec 2 --payload data/payload.bin
    ./mfcpir --role server --port 9001 --n 1331000 --rec 2 --payload data/payload.bin --threads 1
    ./mfcpir --role aid    --port 9002 --n 1331000 --rec 2 --payload data/payload.bin --threads 1
    ./mfcpir --role client --n 1331000 --d 20 --rec 2 --omega data/omega.bin --s3r_stats data/compare_stats.txt --cond "0:>:0,1:==:0" --qmax 20000 --out result.csv
（`--cond` 里的"值"在读取外部 ω 时不起作用，只有"关系"生效。）

## 说明
* `--role gen` / `all` 默认使用明文模拟的比较码（无安全保证）；用 `s3r_compare.py` 生成的 ω 传入 `--omega` 即为真实 s3r 输出。
* 若 |Q| 超过 --qmax/--pad 给出的公开上界，客户端拒绝执行。
* 未指定 --qmax 时按实际 |Q| 取上界，会泄露 |Q|，仅用于测试。
