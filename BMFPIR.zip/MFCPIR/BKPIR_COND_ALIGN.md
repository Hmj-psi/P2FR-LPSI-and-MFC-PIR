# BKPIR 与 MFC-PIR 的参数对齐（d 维比较合取版）

| 含义 | BKPIR | MFC-PIR | 取值 |
|---|---|---|---|
| 行数 | `-m` | `--n` | 8192 / 16384 / 32768 |
| 维度 / 关键词数 | `-n` = 3d | `--d` | d = 10 / 20 / 40，n = 30 / 60 / 120 |
| 每条取回字节数 | `-il` | `--rec` | 2（扫描 2/4/8/16） |
| 特征取值范围 | `-domain` | `--domain` | round(2/(1-0.05^(1/d)))：8 / 14 / 28 |
| 随机种子 | `-seed` | `--seed` | 1（特征生成逐位相同） |
| 检索条件 | `-cond` | `--cond` | 同一个字符串：d 个维度各一个 `j:>:1` 做合取 |
| 多项式次数 | `-N` | — | 16384（d 条件的乘法树要 ceil(log2 d) 层） |

- 数据：BKPIR 的 3d 个关键词是每维的 `==` / `>` / `<`（编号 3j+r），valuemap 由同一份特征与阈值的比较结果生成。
- 命中数：BKPIR 解密后的掩码里 1 的个数 = 明文真值 = MFC 的 |Q|，约 5%。`make_table.py` 会核对。
- 阈值取 1：保证三种关系的 valuemap 都非空（SEAL 的 `multiply_plain` 乘全 0 明文会抛 transparent 异常）。
- MFC 的 `--qmax` 取期望 |Q| 的 1.3 倍（单块时上传量与 qmax 成正比）。
- 不支持 `>=` / `<=`：BKPIR 里要两个关键词做 OR。
- 计时口径：BKPIR 是单线程 CPU 时间；MFC 的选择时间来自独立的 s3r 进程。

---

# 原生 BKPIR 与 MFC-PIR 的功能阶段对比（新增）

上面的 3d 版是为了让 BKPIR 对齐 MFC-PIR 的三路比较码（`==`、`>`、`<`），数据库每维 3 个关键词，**已冻结，不再改动**。
这一组是另一个口径：检索条件固定为 d 个 `j:>:1` 的合取，BKPIR 的库按条件预先生成，**只有 d 个关键词**；MFC-PIR 仍然是原来的步骤（s3r 比较 + DPF 取值），两边同数据、同条件。

| 含义 | BKPIR 原生（菜单 7） | MFC-PIR |
|---|---|---|
| 关键词 / 维度 | `-n` = d，第 j 个关键词的 valuemap = 条件 `j:>:1` 的比较结果 | `--d` |
| 选择次数 | d 个条件 × d 个关键词 ≈ d² 次（3d 版是 3d²） | — |
| 其余参数 | `-m`、`-il`、`-domain`、`-seed`、`-cond`、`-N 16384` 与 3d 版相同 | `--n`、`--rec`、`--domain`、`--seed`、`--cond` |
| 命中数 | 解密掩码里 1 的个数 = 明文真值 = MFC 的 |Q|（约 5%，不是全命中） | |

## 按功能阶段对比（不分离线/在线）

| 阶段 | MFC-PIR | BKPIR |
|---|---|---|
| 1. 特征 / 关键字处理 | s3r 安全比较：秘密份额输入、`>` 与 `<` 两次比较、份额相加得比较码、reveal（`COMPARE耗时`，通信 = s3r 通信） | 选择（对全部关键词各做一遍）+ AND 乘法树的服务器时间；通信 = 上传的加密查询 |
| 2. DPF 取值 / 内积 | 单个服务器的 DPF 求值与取值；通信 = DPF 密钥上传 + 应答下载 | 掩码与 item 池的内积；通信 = 应答下载 |

- 不计入的：BKPIR 里按条件生成 valuemap（明文，协议之外）、关键词和 valuemap 的编码、取值内容的预编码（`Preparation time`，约 0.003 s）；MFC 里数据库加载（`prep_s`）和 client 本地定位行号。
- MFC-PIR 的 s3r 对每个 (行, 维) 做 `>` 和 `<` 两次比较再编码成 0/1/2，支持任意关系的条件；这里保持原样，没有裁成单次比较。
- 阶段 1 通信：MFC = `total_comm_MB` − (`upload_KB` + `download_KB`)/1024；BKPIR = `upload_KB`/1024。这样已有的 CSV 不用重跑就能换算。

## 运行

```bash
bash run_native.sh      # 只新跑 BKPIR 原生版；MFC 与 3d 版结果从 FROZEN 目录（默认 ~/results_final）只读取
```

输出在 `~/results_native/`：`bkpir_native.csv`、`stage_table.md`（三行对照：MFC、BKPIR 原生、BKPIR 3d）。

## 取值长度大于 2 字节时的补位块

`transcoding` 把取值按顺序打包成每组 N 个 16 位字。N=16384 而 m=8192 时，il>2 的数据只够填满一半的块（il=4：2 块里 1 块有数据；il=8：4 块里 2 块；il=16：8 块里 4 块），其余块全 0，SEAL 的 `multiply_plain` 会抛 `result ciphertext is transparent`。
现在的做法：空块用单点非零（槽 0 = 1）占位，和真实块一样走 `multiply_plain` / 重线性化 / 下载，耗时与通信量按 var_l × f 个块计。程序会打印 `payload blocks: X (padding blocks without data: Y)`。本测试只核对掩码，不核对取回的取值内容。
il=2 没有补位块，规模扫描不受影响。
