# MFC-PIR 与 BKPIR 对比：口径、参数、运行指令

## 1. 阶段与指标对应（两边日志用同一组标签）

| 论文对比指标 | BKPIR 日志标签 | MFC-PIR 日志标签 | 含义 |
|---|---|---|---|
| 离线 | `Preparation time` | `Preparation time` | BKPIR：数据库编码；MFC：加载随机串库（DPF 无预处理，≈0） |
| 选择 | `Selection time` | `Selection time` | BKPIR：关键词选择（密文上做）；MFC：s3r 比较（client 定位行号为本地计算，不计入） |
| 取值 | `Inner product time` | `Inner product time` | BKPIR：选择掩码与 item 池内积；MFC：DPF 取随机串 |
| 总计 | `Total server time` | `Total server time` | 选择 + 取值 |
| 上传 | `Upload cost` | `Upload cost` | BKPIR：加密选择向量；MFC：发给 S、AS 的 DPF 密钥之和 |
| 下载 | `Download cost` | `Download cost` | BKPIR：加密答案；MFC：S、AS 的应答之和 |
| 额外 | — | `Selection communication` | MFC 的 s3r 两方通信；`Total communication` = s3r + 上传 + 下载 |

计时口径：BKPIR 用 `clock()`（单线程 CPU 时间）。MFC 用墙钟，服务器线程设为 1，S 与 AS 并行，`Inner product time` 取两者较大者。
`--role client` 三进程模式下该项含网络往返，论文数据建议用 `--role all`（`bench_align.sh`），或看 server/aid 日志里的"计算"时间。

## 2. 对齐规则

| BKPIR | MFC-PIR | 对齐方式 |
|---|---|---|
| m（item 数） | n（行数） | 相等 |
| n（关键词数） | d（维度数） | n = 3·d：把"某维取某个比较码"当作一个关键词（每维 3 个码：=、>、<），每行在每维恰有一个关键词 |
| il（item 字节数） | rec（取回字节数） | 相等 |
| N（多项式次数） | — | N = m（论文设定），仅 BKPIR 有 |
| k（恒重码重量）、kl（关键词长度） | — | 仅 BKPIR 有，取默认 k=4、kl=10 |
| 单关键词查询（选项 1 MMKPIRL 或 2 Single） | 只对 1 个维度设条件 | 对应 |
| BKPIRL-AND（选项 3，2 个关键词合取） | 对 2 个维度设条件并合取 | 对应 |
| 命中数：BKPIR 测试库每个关键词对应全部 m 个 item，开销与命中数无关 | |Q| | 同口径行取 |Q|=n；另给一行 |Q|≈n/64（约 1.6%） |
| 线程 | `--threads 1` | 相等 |

局限：两边的数据库字节数无法完全相同。对齐的是行数 m、关键词数 3d、取回长度 il。MFC 另存 n·d·4 字节的特征库用于 s3r 比较。
安全模型也不同：BKPIR 是单服务器 HE，MFC 是 S/AS 不合谋加两方 s3r。这几点论文里要写明。

## 3. 参数表

| 参数 | BKPIR 参数 | MFC-PIR 参数 | 取值 |
|---|---|---|---|
| 行数 / item 数 | `-m` | `--n` | 8192, 16384, 32768 |
| 维度 / 关键词数 | `-n` = 3d | `--d` | d = 10, 20, 40（BKPIR n = 30, 60, 120）；主配置 d=20 |
| 取回字节数 | `-il` | `--rec` | 2（主配置），扫描 2, 4, 8, 16 |
| 多项式次数 | `-N` | — | = m（8192 / 16384 / 32768） |
| 恒重码重量 | `-k` | — | 4（仅 BKPIR） |
| 关键词长度 | `-kl` | — | 10（仅 BKPIR） |
| 命中数 | — | `--cond` / `--qmax` | |Q|=n：`--cond "0:>=:0,1:>=:0" --qmax n`；|Q|≈n/64：`--cond "0:==:0,1:==:0" --qmax n/32` |
| 块长 | — | `--block` | |Q|=n 取 4096；|Q|小 取 65536（仅 MFC） |
| 服务器线程 | — | `--threads` | 1 |
| 特征取值范围 | — | `--domain` | 8（仅 MFC） |
| 失败概率 | — | `--eps` | 0.0001（仅 MFC，填充上界） |

逻辑数据库大小（il=rec=2）：

| m = 行数 | d | BKPIR n=3d | BKPIR 关键词–item 矩阵 (KB) | BKPIR item 池 il=2 (KB) | MFC 特征库 n·d·4 (KB) | MFC 随机串库 rec=2 (KB) |
|---|---|---|---|---|---|---|
| 8192 | 10 | 30 | 30.0 | 16.0 | 320.0 | 16.0 |
| 8192 | 20 | 60 | 60.0 | 16.0 | 640.0 | 16.0 |
| 8192 | 40 | 120 | 120.0 | 16.0 | 1280.0 | 16.0 |
| 16384 | 10 | 30 | 60.0 | 32.0 | 640.0 | 32.0 |
| 16384 | 20 | 60 | 120.0 | 32.0 | 1280.0 | 32.0 |
| 16384 | 40 | 120 | 240.0 | 32.0 | 2560.0 | 32.0 |
| 32768 | 10 | 30 | 120.0 | 64.0 | 1280.0 | 64.0 |
| 32768 | 20 | 60 | 240.0 | 64.0 | 2560.0 | 64.0 |
| 32768 | 40 | 120 | 480.0 | 64.0 | 5120.0 | 64.0 |

BKPIR 的 n=3d 不能取论文里的 128/256/512。要贴近这三个值，可取 d=43, 85, 171（n=129, 255, 513），但不是精确相等。

## 4. 运行指令

### 4.1 编译
```bash
# MFC-PIR（需要 g++ 与支持 AES-NI 的 x86 CPU）
cd MFCPIR && make && ./mfcpir --role selftest

# BKPIR（需要 Microsoft SEAL >= 4.0 与 cmake）
cd bkpir-main && mkdir -p build && cd build && cmake .. && make
```
BKPIR 的 `scripts/exp_table*.sh` 默认在 build 目录下用 `./bin/bkpir`。如果你的可执行文件不在这个位置，设置 `BIN=` 即可。

### 4.2 MFC-PIR 单次运行（三进程，真实 s3r）
```bash
cd MFCPIR
USE_S3R=1 N=8192 D=20 REC=2 COND="0:==:0,1:==:0" QMAX=256 L=65536 TH=1 bash scripts/run_pipeline.sh
```
不装 secretflow 时去掉 `USE_S3R=1`，比较码用 plain 模拟，选择时间为 0（s3r 未计入）。

手动分步：
```bash
python3 scripts/s3r_compare.py --n 8192 --d 20 --domain 8 --thr "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0" --no_txt --out data
./mfcpir --role payload --n 8192 --rec 2 --payload data/payload.bin
./mfcpir --role server --port 9001 --n 8192 --rec 2 --payload data/payload.bin --threads 1 &
./mfcpir --role aid    --port 9002 --n 8192 --rec 2 --payload data/payload.bin --threads 1 &
./mfcpir --role client --n 8192 --d 20 --rec 2 --omega data/omega.bin --s3r_stats data/compare_stats.txt \
         --cond "0:==:0,1:==:0" --qmax 256 --block 65536 --server 127.0.0.1:9001 --aid 127.0.0.1:9002 --out data/result.csv --stats_csv data/stats.csv
```

### 4.3 BKPIR 单次运行
```bash
cd bkpir-main/build
echo -e "1\n0" | ./bin/bkpir -N 8192 -n 60 -m 8192 -il 2 -k 4     # 选项1 MMKPIRL，单关键词
echo -e "3\n0" | ./bin/bkpir -N 8192 -n 60 -m 8192 -il 2 -k 4     # 选项3 BKPIRL-AND，对应 2 个维度合取
```

### 4.4 对齐的整套扫描
```bash
# 1) 真实 s3r：每组 (n,d) 先跑一次，统计放到 s3r_stats/n{N}_d{D}/compare_stats.txt
for n in 8192 16384 32768; do for d in 10 20 40; do
  python3 scripts/s3r_compare.py --n $n --d $d --domain 8 --thr "$(python3 -c "print(','.join(['0']*$d))")" --no_txt --out s3r_stats/n${n}_d${d}
done; done
# 2) MFC 扫描（不设 S3R_DIR 则选择时间不含 s3r）
S3R_DIR=s3r_stats bash scripts/bench_align.sh                 # 输出 mfc_align.csv
# 3) BKPIR 扫描：把 scripts/bkpir_bench.sh 复制到 bkpir-main/build 下运行
cd bkpir-main/build && bash bkpir_bench.sh              # 输出 bkpir_align.csv
# 4) 合并成表
python3 scripts/make_table.py bkpir_align.csv mfc_align.csv > compare_table.md
```
s3r 的 `--thr` 全取 0、`--domain 8`：`--cond "0:>=:0"` 得到 |Q|=n，`--cond "0:==:0"` 得到 |Q|≈n/64，两种模式共用同一份 ω 和同一份 s3r 统计，每组 (n,d) 只需跑一次 s3r。

## 5. 论文里写的内容
- 同口径行（|Q|=n）用来和 BKPIR 并列比较。|Q|=n 时 PIR 已无意义，只能作为同口径对照。
- |Q| 较小的行单独列出，并写明 |Q|。
- 注明 BKPIR 为单线程 CPU 时间，MFC 为单线程墙钟，且 MFC 的选择阶段（s3r）依赖 client 的阈值，每换一次查询条件要重跑一次。
- BKPIR 选择阶段占 Total server time 的比例是按代码推断的，要看你的实测日志。
