#!/bin/bash
# 一键三进程流水线：s3r 比较(选择) -> client 选码并定位行号 -> DPF 从 S/AS 取每行 REC 字节随机串(取值)
# 用法示例：
#   N=8192 D=20 REC=2 bash scripts/run_pipeline.sh                    # 比较码用 plain 模拟（无 s3r，选择时间为 0（s3r 未计入））
#   USE_S3R=1 N=8192 D=20 REC=2 bash scripts/run_pipeline.sh          # 真实 s3r（需要 secretflow）
# 环境变量：N 行数  D 维度  REC 取回字节数  COND 条件  QMAX |Q| 公开上界  L 块长  TH 服务器线程  THR s3r 阈值(逗号分隔,d个)
set -e
BIN=${BIN:-./mfcpir}
N=${N:-8192}; D=${D:-20}; REC=${REC:-2}; L=${L:-65536}; TH=${TH:-1}; DOMAIN=${DOMAIN:-8}
COND=${COND:-"0:==:0,1:==:0"}; QMAX=${QMAX:-$N}
OUT=${OUT:-data}; mkdir -p "$OUT"
OMEGA="--omega $OUT/omega.bin"; STATS=""

if [ "${USE_S3R:-0}" = "1" ]; then
  # 阈值默认全 0；COND 里的关系需与之配合（值在读取外部比较码时不起作用）
  THR=${THR:-$(python3 -c "print(','.join(['0']*$D))")}
  python3 scripts/s3r_compare.py --n $N --d $D --domain $DOMAIN --thr "$THR" --no_txt --out $OUT
  STATS="--s3r_stats $OUT/compare_stats.txt"
  $BIN --role payload --n $N --rec $REC --payload $OUT/payload.bin
else
  $BIN --role gen --n $N --d $D --rec $REC --domain $DOMAIN --db $OUT/features.bin --omega $OUT/omega.bin \
       --payload $OUT/payload.bin --cond "$COND"
fi

$BIN --role server --port ${PORT_S:-9001} --n $N --rec $REC --payload $OUT/payload.bin --threads $TH > $OUT/server.log 2>&1 & S=$!
$BIN --role aid    --port ${PORT_A:-9002} --n $N --rec $REC --payload $OUT/payload.bin --threads $TH > $OUT/aid.log 2>&1 & A=$!
sleep 1
$BIN --role client --n $N --d $D --rec $REC $OMEGA $STATS --cond "$COND" --qmax $QMAX --block $L \
     --threads $TH --server 127.0.0.1:${PORT_S:-9001} --aid 127.0.0.1:${PORT_A:-9002} \
     --out $OUT/result.csv --stats_csv $OUT/stats.csv
wait $S $A
echo "取回记录: $OUT/result.csv（行号,随机串十六进制）   汇总: $OUT/stats.csv"
