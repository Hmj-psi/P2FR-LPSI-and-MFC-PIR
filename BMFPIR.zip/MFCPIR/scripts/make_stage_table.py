#!/usr/bin/env python3
# 按功能阶段对比 MFC-PIR 与 BKPIR（不分离线/在线）。
#   阶段 1  特征/关键字处理：
#             MFC-PIR : s3r 安全比较（含秘密份额输入、两次比较、份额相加得比较码、reveal）的时间与通信
#             BKPIR   : 选择（对所有关键词各做一遍）+ AND 乘法树 的服务器时间；通信 = 上传的加密查询
#   阶段 2  DPF 取值 / 内积：
#             MFC-PIR : 单个服务器的 DPF 求值与取值时间；通信 = DPF 密钥上传 + 应答下载
#             BKPIR   : 掩码与 item 池的内积时间；通信 = 应答下载
# 输入 CSV 沿用已有格式（bench_align.sh / bkpir_bench.sh / bkpir_native_bench.sh 的输出），无需重跑：
#   MFC-PIR      : 阶段 1 通信 = total_comm_MB - (upload_KB + download_KB)/1024（即 s3r 通信）
#   BKPIR(cond)  : 阶段 1 时间 = total_server_s - inner_product_s（= 选择 + AND），keywords_or_3d = 3d
#   BKPIR(native): 同上，keywords_or_3d = d
# 用法：python3 make_stage_table.py --mfc mfc_align.csv --native bkpir_native.csv [--cond bkpir_align.csv]
import argparse, csv, collections

ap = argparse.ArgumentParser()
ap.add_argument("--mfc", required=True)
ap.add_argument("--native", required=True)
ap.add_argument("--cond", default="", help="可选：3d 关键词（对齐三路比较码）版的 BKPIR 结果，作为第三行对照")
ap.add_argument("--rec_sweep_m", type=int, default=8192)
ap.add_argument("--rec_sweep_d", type=int, default=20)
a = ap.parse_args()

def fnum(x):
    x = float(x)
    if x >= 100: return f"{x:.0f}"
    if x >= 10: return f"{x:.1f}"
    if x >= 1: return f"{x:.2f}"
    return f"{x:.3f}"

def load(path, label):
    out = collections.defaultdict(list)
    for r in csv.DictReader(open(path)):
        proto = r["protocol"]
        kw = int(r["keywords_or_3d"])
        d = kw if proto.startswith("BKPIR(native") else kw // 3
        up, dn = float(r["upload_KB"]), float(r["download_KB"])
        ip, tot = float(r["inner_product_s"]), float(r["total_server_s"])
        if proto.startswith("MFC"):
            s2c = (up + dn) / 1024
            s1c = float(r["total_comm_MB"]) - s2c
            s1t, s2t = float(r["selection_s"]), ip
        else:
            s1t, s2t = tot - ip, ip
            s1c, s2c = up / 1024, dn / 1024
        key = (int(r["m_rows"]), d, int(r["rec_bytes"]))
        out[key].append(dict(Q=r["Q"], s1t=s1t, s1c=s1c, s2t=s2t, s2c=s2c))
    res = {}
    for k, v in out.items():
        qs = {x["Q"] for x in v}
        avg = {f: sum(x[f] for x in v) / len(v) for f in ("s1t", "s1c", "s2t", "s2c")}
        avg["Q"] = qs.pop() if len(qs) == 1 else "/".join(sorted(qs))
        avg["runs"] = len(v)
        res[k] = avg
    return res

mfc = load(a.mfc, "MFC-PIR")
nat = load(a.native, "BKPIR(native)")
cnd = load(a.cond, "BKPIR(cond)") if a.cond else {}

HDR = ["协议", "n", "d", "取值长度", "Q", "阶段1 时间(s)", "阶段1 通信(MB)", "阶段2 时间(s)", "阶段2 通信(MB)", "合计 时间(s)", "合计 通信(MB)"]

def row(name, k, r):
    return [name, str(k[0]), str(k[1]), str(k[2]), r["Q"], fnum(r["s1t"]), fnum(r["s1c"]), fnum(r["s2t"]), fnum(r["s2c"]),
            fnum(r["s1t"] + r["s2t"]), fnum(r["s1c"] + r["s2c"])]

def table(keys, title):
    print(f"\n### {title}\n")
    print("| " + " | ".join(HDR) + " |"); print("|" + "---|" * len(HDR))
    for k in keys:
        for name, src in (("MFC-PIR", mfc), ("BKPIR(原生, d个关键词)", nat), ("BKPIR(3d个关键词)", cnd)):
            if k in src: print("| " + " | ".join(row(name, k, src[k])) + " |")

common = sorted(set(mfc) & set(nat))
scale = [k for k in common if k[2] == 2]
rec = [k for k in common if (k[0], k[1]) == (a.rec_sweep_m, a.rec_sweep_d)]
table(scale, "规模扫描（取值长度 2 字节）")
table(rec, f"取值长度扫描（n={a.rec_sweep_m}，d={a.rec_sweep_d}）")

# Q 一致性
bad = []
for k in common:
    qs = {mfc[k]["Q"], nat[k]["Q"]} | ({cnd[k]["Q"]} if k in cnd else set())
    if len(qs) > 1: bad.append((k, qs))
print()
if bad:
    print("**警告：以下配置的检索结果数 Q 不一致，结果不能直接对比：**")
    for k, qs in bad: print(f"- n={k[0]} d={k[1]} rec={k[2]}: {sorted(qs)}")
else:
    print(f"Q 核对：{len(common)} 组配置上各协议的检索结果数完全一致。")
miss = sorted(set(mfc) ^ set(nat))
if miss: print("\n注意：下列配置只在其中一边有数据（未列入对比）：", miss)
dup = [k for k, v in list(mfc.items()) + list(nat.items()) if v["runs"] > 1]
if dup: print("\n说明：同一配置出现多次的行（规模扫描与取值长度扫描重叠）已取平均。")
