#!/bin/bash
# BKPIR 侧参数扫描：在 BKPIR 的 build 目录里运行（可执行文件 ./bin/bkpir）。输出与 MFC 侧 bench_align.sh 同列的 CSV。
# 对齐：-m = MFC 的 n（行数）；-n = 3*d（每维 ==、>、< 三个关键词）；-il = rec；同 -seed、同 -domain、同检索条件。
# 查询：菜单 6（BKPIRL-COND）：d 个维度各一个条件 "j:>:1" 做合取，与 MFC 的 --cond 完全相同；
#       三个 |Q| 必须一致：明文真值、解密后的掩码里 1 的个数（本脚本写入 CSV 的 Q 列）、MFC 日志里的 |Q|。
# 多层 AND 的噪声预算：N=8192 只够 1 层，d 个条件的乘法树要 ceil(log2 d) 层，所以统一用 NPOLY=16384。
# 命中率：HIT 默认 0.05；domain = round(2/(1-HIT^(1/d)))，阈值取 1，单维命中概率 (domain-2)/domain。
BIN=${BIN:-./bin/bkpir}; K=${K:-4}; NPOLY=${NPOLY:-16384}; HIT=${HIT:-0.05}; SEED=${SEED:-1}
OUT=${OUT:-bkpir_align.csv}; LOGDIR=${LOGDIR:-bkpir_align_logs}; mkdir -p $LOGDIR
ROWS=(${ROWS:-8192 16384 32768}); DIMS=(${DIMS:-10 20 40}); RECS=(${RECS:-2 4 8 16}); REC_SWEEP_M=${REC_SWEEP_M:-8192}; REC_SWEEP_D=${REC_SWEEP_D:-20}
echo "protocol,m_rows,keywords_or_3d,rec_bytes,Q,prep_s,selection_s,inner_product_s,total_server_s,upload_KB,download_KB,total_comm_MB" > $OUT
tokb() { echo "$1" | sed 's/MB/*1024/; s/KB//' | bc; }
domain_for_d() { python3 -c "print(round(2/(1-$HIT**(1/$1))))"; }
run() {  # m d il
  local m=$1 d=$2 il=$3 n=$((3*$2)) D=$(domain_for_d $2)
  local cond=$(python3 -c "print(','.join(f'{j}:>:1' for j in range($d)))")
  local log=$LOGDIR/N${NPOLY}_d${d}_m${m}_il${il}_cond.log
  echo "[BKPIR] m=$m d=$d il=$il domain=$D N=$NPOLY $(date +%T)" >&2
  echo -e "6\n0" | $BIN -N $NPOLY -n $n -m $m -il $il -k $K -domain $D -seed $SEED -cond "$cond" > $log 2>&1
  if ! grep -q "Mask check: OK" $log; then echo "失败或掩码核对未通过（噪声预算不足？）: $log" >&2; grep -E "Error:|WARNING|Noise budget" $log >&2; return; fi
  local prep=$(grep "Preparation time:" $log | awk '{print $3}')
  local sel=$(grep -E "^Selection time:|^Total selection time:" $log | tail -1 | awk '{print $NF=="seconds"?$(NF-1):$NF}')
  local ip=$(grep "Inner product time:" $log | awk '{print $4}')
  local tot=$(grep -E "otal server time:" $log | awk '{print $(NF-1)}')
  local up=$(tokb "$(grep 'Upload cost:' $log | awk '{print $3 $4}')")
  local dn=$(tokb "$(grep 'Download cost:' $log | awk '{print $3 $4}')")
  local q=$(grep "Q (decrypted mask):" $log | awk '{print $NF}')
  echo "BKPIR(cond),$m,$n,$il,$q,$prep,$sel,$ip,$tot,$up,$dn,$(echo "scale=4;($up+$dn)/1024" | bc)" >> $OUT
}
for m in "${ROWS[@]}"; do for d in "${DIMS[@]}"; do run $m $d 2; done; done        # 规模扫描
for il in "${RECS[@]}"; do run $REC_SWEEP_M $REC_SWEEP_D $il; done                  # 取值长度扫描
echo "完成：$OUT（日志在 $LOGDIR/）"
