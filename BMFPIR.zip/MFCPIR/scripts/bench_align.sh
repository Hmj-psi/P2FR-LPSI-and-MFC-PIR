#!/bin/bash
# 与 BKPIR 对齐的参数扫描（单进程 role all，通信字节为真实序列化大小）
# 对齐规则：BKPIR 的 m(item 数) = 本协议的 n(行数)；BKPIR 的 n(关键词数) = 3*d；il = rec；线程均为 1；同 seed、同 domain、同检索条件。
# 检索条件：d 个维度各一个 "j:>:1" 做合取（所有维度都参与筛选），与 BKPIR 菜单 6 的 -cond 是同一个字符串。
#   阈值取 1 的原因：BKPIR 要求每个维度的 ==、>、< 三个关键词 valuemap 都非空（SEAL 不允许乘全 0 明文）。
# 命中率：HIT 默认 0.05；domain = round(2/(1-HIT^(1/d)))，单维命中概率 (domain-2)/domain，|Q| ≈ n*((domain-2)/domain)^d。
#   d=10→domain 8 (≈5.6%)，d=20→14 (≈4.6%)，d=40→28 (≈5.2%)。
# --qmax（|Q| 的公开上界，单块时 pad=qmax，上传量与它成正比）取期望 |Q| 的 1.3 倍；实际 |Q| 超过则程序会报错，可调大 QMAX_FACTOR。
# 输出 CSV：与 scripts/bkpir_bench.sh 同列，可用 scripts/make_table.py 合并（会核对两边的 Q 是否一致）
# s3r 的耗时/通信：设 S3R_DIR=<目录>，目录下按 n{N}_d{D}/compare_stats.txt 放真实 s3r 统计；不设则选择时间为 0（s3r 未计入）
#   s3r 比较的开销只取决于 n、d（int32 秘密共享比较），与 domain/阈值无关，所以之前跑好的 s3r 统计可以直接复用。
BIN=${BIN:-./mfcpir}
OUT=${OUT:-mfc_align.csv}
HIT=${HIT:-0.05}; QMAX_FACTOR=${QMAX_FACTOR:-1.3}; SEED=${SEED:-1}
ROWS=(${ROWS:-8192 16384 32768}); DIMS=(${DIMS:-10 20 40}); RECS=(${RECS:-2 4 8 16}); REC_SWEEP_N=${REC_SWEEP_N:-8192}; REC_SWEEP_D=${REC_SWEEP_D:-20}
L=${L:-65536}
echo "protocol,m_rows,keywords_or_3d,rec_bytes,Q,prep_s,selection_s,inner_product_s,total_server_s,upload_KB,download_KB,total_comm_MB" > $OUT
run() {  # n d rec
  local n=$1 d=$2 rec=$3 extra=""
  local D=$(python3 -c "print(round(2/(1-$HIT**(1/$d))))")
  local cond=$(python3 -c "print(','.join(f'{j}:>:1' for j in range($d)))")
  local qmax=$(python3 -c "import math;print(math.ceil($QMAX_FACTOR*$n*(($D-2)/$D)**$d))")
  [ -n "$S3R_DIR" ] && extra="--s3r_stats $S3R_DIR/n${n}_d${d}/compare_stats.txt"
  local csv=$(mktemp)
  echo "[MFC] n=$n d=$d rec=$rec domain=$D qmax=$qmax" >&2
  $BIN --role all --n $n --d $d --rec $rec --domain $D --cond "$cond" --qmax $qmax --block $L --threads 1 \
       --seed $SEED --eps 0.0001 --show 0 --stats_csv $csv $extra > /dev/null || { echo "失败: n=$n d=$d rec=$rec" >&2; rm -f $csv; return; }
  # csv 列: n,d,Q,rec,threads,prep,sel,ip,tot,up,down,s3r_comm,total_comm
  tail -1 $csv | awk -F, '{printf "MFC-PIR,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",$1,3*$2,$4,$3,$6,$7,$8,$9,$10,$11,$13}' >> $OUT
  rm -f $csv
}
for n in "${ROWS[@]}"; do for d in "${DIMS[@]}"; do run $n $d 2; done; done        # 规模扫描（il=2）
for rec in "${RECS[@]}"; do run $REC_SWEEP_N $REC_SWEEP_D $rec; done                # 取值长度扫描
echo "完成：$OUT"
