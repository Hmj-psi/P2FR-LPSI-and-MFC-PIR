# s3r 比较阶段（基于原 s3r-.py 改写）
# 作用：sender 持有 n×d 特征库，receiver 持有每维的比较值 thr[j]；
#       用 SPU(SEMI2K) 秘密共享比较，得到比较码 ω[i][j] ∈ {0,1,2}（0=相等，1=sender>receiver，2=sender<receiver）。
# 与原脚本的区别：
#   1) 数据库 features.bin 落盘（int32 小端行优先），C++ 的 server / aid 要加载"同一份"库；
#   2) 比较码同时输出 compare_result.txt（与原脚本格式一致）和 omega.bin（n*d 字节，读取更快）；
#   3) n、d、阈值、输出目录改为命令行参数；
# 注意：sf.reveal 会把 ω 明文给所有人（仿真）。真实协议中 ω 只应交给 receiver（client），
#       可改为把 res 直接发给 receiver（例如 res.to(receiver)，请按你的 SecretFlow 版本核对该接口）。
import argparse, math, os, sys, time
from io import StringIO

import numpy as np
import secretflow as sf

ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=math.ceil(1.27 * (1 << 20)))
ap.add_argument("--d", type=int, default=20)
ap.add_argument("--thr", type=str, default="", help="逗号分隔的 d 个比较值；留空则随机")
ap.add_argument("--domain", type=int, default=0, help=">0 时特征与阈值取自 [0,domain)，便于出现相等；0 为全 int32 范围")
ap.add_argument("--seed", type=int, default=1)
ap.add_argument("--out", type=str, default=".")
ap.add_argument("--no_txt", action="store_true", help="不写 compare_result.txt（大规模时很慢）")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
n, d = args.n, args.d
rng = np.random.default_rng(args.seed)


class Capturing:
    def __enter__(self):
        self._old = sys.stdout
        sys.stdout = self._s = StringIO()
        return self

    def __exit__(self, *a):
        self.output = self._s.getvalue()
        sys.stdout = self._old


if args.domain > 0:
    feats = rng.integers(0, args.domain, size=(n, d), dtype=np.int32)
    thr = rng.integers(0, args.domain, size=d, dtype=np.int32)
else:
    lo, hi = np.iinfo(np.int32).min, np.iinfo(np.int32).max
    feats = rng.integers(lo, hi, size=(n, d), dtype=np.int32)
    thr = rng.integers(lo, hi, size=d, dtype=np.int32)
if args.thr:
    thr = np.array([int(x) for x in args.thr.split(",")], dtype=np.int32)
    assert len(thr) == d, "--thr 的个数必须等于 --d"
pred = np.tile(thr, (n, 1))

# 数据库落盘：服务器与辅助服务器加载同一份
feats.astype("<i4").tofile(os.path.join(args.out, "features.bin"))

sf.init(["sender", "receiver"], address="local")
cfg = sf.utils.testing.cluster_def(
    parties=["sender", "receiver"],
    runtime_config={"protocol": "SEMI2K", "field": "FM64",
                    "enable_pphlo_profile": True, "enable_hal_profile": True},
)
spu = sf.SPU(cfg)
sender, receiver = sf.PYU("sender"), sf.PYU("receiver")


def greater(x, y): return x > y
def smaller(x, y): return x < y
def code(g, s): return g.astype(int) * 1 + s.astype(int) * 2  # 0=等于 1=大于 2=小于


def COMPARE():
    x = sf.to(sender, feats)
    y = sf.to(receiver, pred)
    g = spu(greater)(x, y)
    s = spu(smaller)(x, y)
    return spu(code)(g, s)


with Capturing() as cap:
    t0 = time.perf_counter()
    res = COMPARE()
    omega = np.asarray(sf.reveal(res))
    t1 = time.perf_counter()

omega = np.rint(omega).astype(np.int64)
assert omega.shape == (n, d) and omega.min() >= 0 and omega.max() <= 2, "比较码形状或取值异常"

# 通信量（同原脚本的日志解析）
sent = recv = 0
for line in cap.output.split("\n"):
    if "send bytes" in line and "recv bytes" in line:
        p = line.strip().split()
        try:
            sent += int(p[p.index("send") + 2]); recv += int(p[p.index("recv") + 2])
        except (ValueError, IndexError):
            pass

omega.astype(np.uint8).tofile(os.path.join(args.out, "omega.bin"))
if not args.no_txt:
    with open(os.path.join(args.out, "compare_result.txt"), "w") as f:
        for row in omega:
            f.write(" ".join(map(str, row)) + "\n")

# 明文校验：SPU 结果应与直接比较一致
expect = (feats > pred).astype(np.int64) + 2 * (feats < pred).astype(np.int64)
print("SPU 比较码与明文一致:", bool((omega == expect).all()))
with open(os.path.join(args.out, "compare_stats.txt"), "w") as f:
    f.write(f"n={n} d={d}\nCOMPARE耗时: {t1 - t0:.6f} s\n发送: {sent:,} B\n接收: {recv:,} B\n"
            f"总通信: {(sent + recv) / 1048576:.2f} MB\n阈值: {','.join(map(str, thr))}\n")
print("完成：features.bin / omega.bin / compare_stats.txt 已写入", args.out)
sf.shutdown()
