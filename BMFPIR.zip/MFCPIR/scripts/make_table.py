# 合并两个协议的 CSV，输出论文对比表（markdown），并核对两边的检索结果数 Q 是否一致。
# 用法：python3 scripts/make_table.py bkpir_align.csv mfc_align.csv
import csv, sys
rows = []
for p in sys.argv[1:]:
    rows += list(csv.DictReader(open(p)))
rows.sort(key=lambda r: (int(r["m_rows"]), int(r["keywords_or_3d"]), int(r["rec_bytes"]), r["protocol"]))
hdr = ["protocol", "m_rows", "keywords_or_3d", "rec_bytes", "Q", "selection_s", "inner_product_s", "total_server_s", "upload_KB", "download_KB", "total_comm_MB"]
print("| " + " | ".join(hdr) + " |"); print("|" + "---|" * len(hdr))
for r in rows: print("| " + " | ".join(r[h] for h in hdr) + " |")

# Q 一致性：同一 (m, 3d) 下，BKPIR 与 MFC-PIR 的 Q 必须相等（同数据、同条件）
by = {}
for r in rows:
    by.setdefault((r["m_rows"], r["keywords_or_3d"]), {})[r["protocol"].split("(")[0]] = r["Q"]
bad = [(k, v) for k, v in by.items() if len(set(v.values())) > 1]
print()
if bad:
    print("**警告：以下配置两边的 Q 不一致，结果不能直接对比：**")
    for (m, n3d), v in bad: print(f"- m={m}, 3d={n3d}: {v}")
else:
    print(f"Q 核对：{len(by)} 组配置两边的检索结果数完全一致。")
